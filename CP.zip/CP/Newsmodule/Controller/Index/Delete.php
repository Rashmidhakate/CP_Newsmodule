<?php

namespace CP\Newsmodule\Controller\Index;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Exception\LocalizedException;

class Delete extends \Magento\Framework\App\Action\Action {

    public function __construct(Context $context) {
        parent::__construct($context);
    }

    public function execute() {

        $id = $this->getRequest()->getParam('id');
        if ($id) {

            try {

                $model = $this->_objectManager->create('CP\Newsmodule\Model\Newsmodule');
                
                $model->load($id);

                $model->delete();
                $this->_redirect('newsmodule/*/post');
                $this->messageManager->addSuccess(__('Deleted News successfully.'));
                return;
            } catch (LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addError(
                    __('We can\'t delete this News right now. Please review the log and try again.')
                );
                $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
                $this->_redirect('newsmodule/*/post', ['id' => $this->getRequest()->getParam('id')]);
                return;
            }
        }
        $this->messageManager->addError(__('We can\'t find a rule to delete.'));
        $this->_redirect('newsmodule/*/');
    }
}

