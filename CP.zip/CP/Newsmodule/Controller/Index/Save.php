<?php
 
namespace CP\Newsmodule\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use CP\Newsmodule\Model\NewsmoduleFactory;
use CP\Newsmodule\Model\ResourceModel\Newsmodule\CollectionFactory; 

class Save extends \Magento\Framework\App\Action\Action
{
    protected $_resultPageFactory;
    protected $newsmoduleModel;
    protected $_messageManager;
    protected $collectionFactory;

    public function __construct(Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        NewsmoduleFactory $newsmoduleModel,
        CollectionFactory $collectionFactory,  
        \Magento\Framework\Message\ManagerInterface $messageManager
    )
    {
        $this->_resultPageFactory = $resultPageFactory;
        $this->newsmoduleModel = $newsmoduleModel;
        $this->collectionFactory = $collectionFactory;
        $this->_messageManager = $messageManager;
        parent::__construct($context);
    }
 
    public function execute()
    {
        $resultPage = $this->_resultPageFactory->create();
        $post = $this->getRequest()->getPostValue();
        
        if (!$post) {
            $this->_redirect('');
            return;
        }
        $model = $this->newsmoduleModel->create();
        if($this->getRequest()->getParam('id')){
            $model->load($this->getRequest()->getParam('id'));
        }
        $model->setSummary($post['name'])
            ->setDescription($post['description'])
              ->setDate($post['datepicker'])
              ->setStatus($post['status'])
              ->setShort_description($post['shortdescription'])
              ->save();
              //print_r($post);
              //exit;
              
        $this->_redirect('newsmodule/*/post');
        $this->_messageManager->addSuccess("Data successfully inserted");
        return $resultPage;
    }
}