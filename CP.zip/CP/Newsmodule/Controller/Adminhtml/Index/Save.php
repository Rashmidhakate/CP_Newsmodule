<?php
namespace CP\Newsmodule\Controller\Adminhtml\Index;
use Magento\Framework\App\Filesystem\DirectoryList;

use Magento\Backend\App\Action;
use Magento\TestFramework\ErrorLog\Logger;

class Save extends \Magento\Backend\App\Action
{
    protected $cacheTypeList;
    protected $jsHelper;

    const ADMIN_RESOURCE = 'CP_Newsmodule::save';
    protected $adapterFactory;
    protected $uploader;
    protected $filesystem;


    protected $_filesystem;
    protected $_storeManager;
    protected $_directory;
    protected $_imageFactory;

    public function __construct(
        Action\Context $context,
        \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList,
        \Magento\Backend\Helper\Js $jsHelper,
        \Magento\Framework\Image\AdapterFactory $adapterFactory,
        \Magento\MediaStorage\Model\File\UploaderFactory $uploader,        

        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Image\AdapterFactory $imageFactory
    )
    {        
        $this->_storeManager = $storeManager;
        $this->_directory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_imageFactory = $imageFactory;

        $this->adapterFactory = $adapterFactory;
        $this->uploader = $uploader;
        $this->filesystem = $filesystem;
        $this->cacheTypeList = $cacheTypeList;
        parent::__construct($context);
        $this->jsHelper = $jsHelper;
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed(self::ADMIN_RESOURCE);
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        
        
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($data) {
           
            

            //start block upload image
            // if (isset($_FILES['event_image']) && isset($_FILES['event_image']['name']) && strlen($_FILES['event_image']['name'])) {
            //     /*
            //     * Save image upload
            //     */
            //     try {
            //         $base_media_path = 'cp/events/images/';
            //         $uploader = $this->uploader->create(
            //             ['fileId' => 'event_image']
            //         );
            //         $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
            //         $uploader->setAllowRenameFiles(true);
            //         $imageAdapter = $this->adapterFactory->create();
            //         $uploader->addValidateCallback('event_image', $imageAdapter, 'validateUploadFile');
            //         $uploader->setAllowRenameFiles(true);
            //         $mediaDirectory = $this->filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);

            //         $result = $uploader->save(
            //             $mediaDirectory->getAbsolutePath($base_media_path)
            //         );
            //         // Resize and keep save new folder //
            //         $this->imageResize($_FILES['event_image']['name'],'579','379',$base_media_path,$base_media_path."resized/");
                    
            //         // Resize and keep save new folder //

            //         $data['event_image'] = $result['name'];
            //     } catch (\Exception $e) {
            //         if ($e->getCode() == 0) {
            //             $this->messageManager->addError($e->getMessage());
            //         }
            //     }
            // }
            // if (isset($_FILES['event_listpage_image']) && isset($_FILES['event_listpage_image']['name']) && strlen($_FILES['event_listpage_image']['name'])) {
            //     /*
            //     * Save image upload
            //     */
            //     try {
            //         $base_media_path = 'cp/events/images/listpage';
            //         $uploader = $this->uploader->create(
            //             ['fileId' => 'event_listpage_image']
            //         );
            //         $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
            //         $uploader->setAllowRenameFiles(true);
            //         $imageAdapter = $this->adapterFactory->create();
            //         $uploader->addValidateCallback('event_listpage_image', $imageAdapter, 'validateUploadFile');
            //         $uploader->setAllowRenameFiles(true);
            //         $mediaDirectory = $this->filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);

            //         $result = $uploader->save(
            //             $mediaDirectory->getAbsolutePath($base_media_path)
            //         );
            //         // Resize and keep save new folder //
            //         $this->imageResize($_FILES['event_listpage_image']['name'],'544','394',$base_media_path,$base_media_path."resized/listpage");
                    
            //         // Resize and keep save new folder //

            //         $data['event_listpage_image'] = $result['name'];
            //     } catch (\Exception $e) {
            //         if ($e->getCode() == 0) {
            //             $this->messageManager->addError($e->getMessage());
            //         }
            //     }
            // }
            // if (isset($_FILES['event_detailpage_image']) && isset($_FILES['event_detailpage_image']['name']) && strlen($_FILES['event_detailpage_image']['name'])) {
            //     /*
            //     * Save image upload
            //     */
            //     try {
            //         $base_media_path = 'cp/events/images/detailpage';
            //         $uploader = $this->uploader->create(
            //             ['fileId' => 'event_detailpage_image']
            //         );
            //         $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
            //         $uploader->setAllowRenameFiles(true);
            //         $imageAdapter = $this->adapterFactory->create();
            //         $uploader->addValidateCallback('event_detailpage_image', $imageAdapter, 'validateUploadFile');
            //         $uploader->setAllowRenameFiles(true);
            //         $mediaDirectory = $this->filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);

            //         $result = $uploader->save(
            //             $mediaDirectory->getAbsolutePath($base_media_path)
            //         );
            //         // Resize and keep save new folder //
            //         $this->imageResize($_FILES['event_detailpage_image']['name'],'609','740',$base_media_path,$base_media_path."resized/detailpage");
                    
            //         // Resize and keep save new folder //

            //         $data['event_detailpage_image'] = $result['name'];
            //     } catch (\Exception $e) {
            //         if ($e->getCode() == 0) {
            //             $this->messageManager->addError($e->getMessage());
            //         }
            //     }
            // }
            
            $model = $this->_objectManager->create('CP\Newsmodule\Model\Newsmodule');

            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }

            $model->setData($data);

            try {
                $model->save();

                $this->cacheTypeList->invalidate('full_page');
                $this->messageManager->addSuccess(__('You saved this News.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId(), '_current' => true]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the News.'));
            }

            //$this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    // public function imageResize($image, $width = null, $height = null,$absPath,$resizepath)
    // {

    //     $absPath = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath($absPath).$image;;
    //     //echo $absPath;exit;
    //     if(!file_exists($absPath)){
    //         return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'cp/events/images/resized/noimage.jpg';
    //     }
    //     $imageResized = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath($resizepath).$image;
    //     $imageResize = $this->_imageFactory->create();         
    //     $imageResize->open($absPath);
    //     $imageResize->constrainOnly(TRUE);         
    //     $imageResize->keepTransparency(TRUE);         
    //     $imageResize->keepFrame(FALSE);         
    //     $imageResize->keepAspectRatio(TRUE);         
    //     $imageResize->resize($width,$height);  
    //     $destination = $imageResized ;    
    //     $imageResize->save($destination);         
    //     $resizedURL= $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).$resizepath.$image;
    //     return $resizedURL;  
    // }
}
