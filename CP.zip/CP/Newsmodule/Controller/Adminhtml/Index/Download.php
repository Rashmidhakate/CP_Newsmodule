<?php
/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace CP\Newsmodule\Controller\Adminhtml\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Download extends \Magento\Framework\App\Action\Action
{
/**
* @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
*/
protected $_productCollectionFactory;
    
public function __construct(
     Context $context,
     \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
) {
     $this->_productCollectionFactory = $productCollectionFactory;
     parent::__construct($context);
}
public function execute()
{
    echo "hioi";
     $notificationId = $this->getRequest()->getParam('filename');
     $heading = [
         __('id'),
         __('summary'),
         __('description'),
         __('date'),
         __('status'),
         __('short_description')
     ];
     $outputFile = "export". date('Ymd_His').".csv";
     $handle = fopen($outputFile, 'w');
     fputcsv($handle, $heading);
     foreach ($productCollection as $product) {
         $row = [
             $product->getId(),
             $product->getSummary(),
             $product->getDescription(),
             $product->getDate(),
             $product->getStatus(),
             $product->getShortDescription()           
         ];
         fputcsv($handle, $row);
     }
     $this->downloadCsv($outputFile);
}

public function downloadCsv($file)
{
     if (file_exists($file)) {
         //set appropriate headers
         header('Content-Description: File Transfer');
         header('Content-Type: application/csv');
         header('Content-Disposition: attachment; filename='.basename($file));
         header('Expires: 0');
         header('Cache-Control: must-revalidate');
         header('Pragma: public');
         header('Content-Length: ' . filesize($file));
         ob_clean();flush();
         readfile($file);
     }
}
}