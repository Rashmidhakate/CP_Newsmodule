<?php

namespace CP\Newsmodule\Controller\Adminhtml\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends Action {
	protected $resultPageFactory;

	public function __construct(Context $context, PageFactory $pageFactory) {
		$this->resultPageFactory = $pageFactory;
		parent::__construct($context);
	}

	public function execute() {

		$resultPage = $this->resultPageFactory->create();

		return $resultPage;
	}

	protected function _isAllowed() {
		return $this->_authorization->isAllowed('CP_Newsmodule::first_level_demo');
	}

	public function getResultPage() {
		if (is_null($this->_resultPage)) {
			$this->_resultPage = $this->_resultPageFactory->create();
		}
		return $this->_resultPage;
	}

	protected function _setPageData() {
		$resultPage = $this->getResultPage();
		$resultPage->setActiveMenu('CP_Newsmodule::second_level_demo');
		$resultPage->getConfig()->getTitle()->prepend((__('News')));

		//Add bread crumb
		// $resultPage->addBreadcrumb(__('Mageplaza'), __('Mageplaza'));
		// $resultPage->addBreadcrumb(__('Hello World'), __('Manage Blogs'));

		return $this;
	}
}