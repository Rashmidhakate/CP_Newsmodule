<?php

namespace CP\Newsmodule\Controller\Adminhtml;

abstract class index extends \Magento\Backend\App\Action {
	protected $_coreRegistry = null;

	public function __construct(\Magento\Backend\App\Action\Context $context, \Magento\Framework\Registry $coreRegistry) {
		$this->_coreRegistry = $coreRegistry;
		parent::__construct($context);
	}

	protected function initPage($resultPage) {
		$resultPage->setActiveMenu('CP_Newsmodule::cp_newsmodule')
			->addBreadcrumb(__('News Event'), __('News Event'))
			->addBreadcrumb(__('Events'), __(''));
		return $resultPage;
	}

	protected function _isAllowed() {
		return $this->_authorization->isAllowed('CP_Newsmodule::newsmodule_menu');
	}
}