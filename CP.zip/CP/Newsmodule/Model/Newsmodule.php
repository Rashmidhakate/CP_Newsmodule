<?php
namespace CP\Newsmodule\Model;
class Newsmodule extends \Magento\Framework\Model\AbstractModel
{
	  protected $_eventsCollectionFactory;

   
    protected $_storeViewId = null;

    
    protected $_eventsFactory;

   
    protected $_formFieldHtmlIdPrefix = 'page_';

    
    protected $_storeManager;

   
    protected $_monolog;

    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \CP\Newsmodule\Model\ResourceModel\Newsmodule $resource,
        \CP\Newsmodule\Model\ResourceModel\Newsmodule\Collection $resourceCollection,
        \CP\Newsmodule\Model\NewsmoduleFactory $eventsFactory,
        
        \CP\Newsmodule\Model\ResourceModel\Newsmodule\CollectionFactory $eventsCollectionFactory,
    
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Logger\Monolog $monolog
    ) {
        parent::__construct(
            $context,
            $registry,
            $resource,
            $resourceCollection
        );
        $this->_eventsFactory = $eventsFactory;
       
      
        $this->_storeManager = $storeManager;
        $this->_eventsCollectionFactory = $eventsCollectionFactory;

        $this->_monolog = $monolog;

        if ($storeViewId = $this->_storeManager->getStore()->getId()) {
            $this->_storeViewId = $storeViewId;
        }
    }

    protected function _construct()
    {
        $this->_init('CP\Newsmodule\Model\ResourceModel\Newsmodule');
    }
}

