<?php
namespace CP\Newsmodule\Model\ResourceModel;
use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;
class Newsmodule extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('cp_newsmodule','id');
    }
}

