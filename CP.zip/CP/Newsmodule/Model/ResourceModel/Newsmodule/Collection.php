<?php
namespace CP\Newsmodule\Model\ResourceModel\Newsmodule;



class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
    protected function _construct()
    {
        $this->_init('CP\Newsmodule\Model\Newsmodule','CP\Newsmodule\Model\ResourceModel\Newsmodule');
    }
}