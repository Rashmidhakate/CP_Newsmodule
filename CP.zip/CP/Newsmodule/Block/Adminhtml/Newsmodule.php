<?php 
namespace CP\Newsmodule\Block\Adminhtml;
 
class Newsmodule extends \Magento\Backend\Block\Widget\Grid\Container
{
    protected function _construct()
    {
        $this->_blockGroup = 'CP_Newsmodule';
        $this->_controller = 'adminhtml_newsmodule';
        $this->_headerText = __('News');
        $this->_addButtonLabel = __('Add News');
        parent::_construct();
    }
}
