<?php

namespace CP\Newsmodule\Block\Adminhtml;

class Button extends \Magento\Backend\Block\Widget\Grid\Container
{
    protected function _construct()
    {
        $this->_blockGroup = 'CP_Newsmodule';
        $this->_controller = 'adminhtml_new';
        $this->_headerText = __('Items');
        $this->_addButtonLabel = __('Add New Item');
        parent::_construct();
    }
}
