<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace CP\Newsmodule\Block;

use Magento\Framework\View\Element\Template;

/**
 * Main contact form block
 */
class Newsmodule extends Template{

    protected $_newsmoduleFactory; 

	 public function __construct(Template\Context $context,
        \CP\Newsmodule\Model\NewsmoduleFactory $newsFactory,
        \Magento\Framework\App\Request\Http $request,
         array $data = [])
    {
        $this->_newsmoduleFactory = $newsFactory;
        $this->request = $request;
        parent::__construct($context, $data);
    } 

	public function getFormAction(){
        if($this->getRequest()->getParam('id')){
            return $this->getUrl('newsmodule/index/save/id/'.$this->getRequest()->getParam('id'));    
        } else {
            return $this->getUrl('newsmodule/index/save');
        }
        return $this->getUrl('newsmodule/index/save');
	}
	public function getCollection()
    {
        $id=$this->getRequest()->getParam('id') ;
        return $this->_newsmoduleFactory->create()->load($id); 
    }
    public function getnewscollection()
    {
        $data=$this->_newsmoduleFactory->create()->getCollection();
        return $data;
    }
    public function getDeleteUrl($id) {
        return $this->getUrl('newsmodule/index/delete', array('id' => $id));
    }
    public function getEditUrl($id){
        return $this->getUrl('newsmodule/index/edit', array('id' => $id));
    }
    public function getNewUrl(){
        return $this->getUrl('newsmodule/index/new');
    }
}